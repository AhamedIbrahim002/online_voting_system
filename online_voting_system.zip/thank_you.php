<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Thank You</title>
    <link rel="stylesheet" href="css/style.css">

</head>
<body>
<div class="container">
    <h1>Thank You!</h1>
    <p>Your vote has been successfully recorded.</p>
    <a href="index.html">Back to Home</a>
</div>
</body>
</html>
